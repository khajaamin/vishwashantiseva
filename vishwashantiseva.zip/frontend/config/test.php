<?php
return [
    'id' => 'app-frontend-tests',
];
